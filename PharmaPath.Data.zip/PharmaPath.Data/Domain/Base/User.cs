﻿namespace PharmaPath.Data.Domain;

public partial class User 
{
    public string FullName { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
    public string EmailId { get; set; } = string.Empty;
    public bool IsActive { get; set; }
    public int Id { get; set; } 
}
