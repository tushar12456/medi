﻿namespace PharmaPath.Data.Domain.Base
{
    public class Medicine : BaseDomain
    {
        public string MedicineName { get; set; } = string.Empty;
        public string BrandName { get; set; } = string.Empty;
        public string BatchName { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public string HsnCode { get; set; } = string.Empty;
        public string Rack { get; set; } = string.Empty;
        public DateTime MfgDate { get; set; }
        public DateTime ExpDate { get; set; }
        public string StockQty { get; set; } = string.Empty;
        public string PurchaseRate { get; set; } = string.Empty;
        public string SalesRate { get; set; } = string.Empty;
        public string Gst { get; set; } = string.Empty;
    }
}
