﻿namespace PharmaPath.Data.Domain.Base
{
    public class  PurchaseMedicine : BaseDomain
    {
        public int PurchaseMedicineId { get; set; }
        public int PurchaseEntryId { get; set; } 
        public string PurchaseBillNo { get; set; } = string.Empty;
        public string MedicineName { get; set; } = string.Empty;
        public string Batch { get; set; } = string.Empty;
        public string HSN { get; set; } = string.Empty;
        public DateTime? MfgDate { get; set; }
        public DateTime? ExpiryDate { get; set; }
        public int Qty { get; set; }
        public decimal PurchaseRate { get; set; }
        public decimal SalesRate { get; set; }
        public decimal GST { get; set; }
        public decimal FinalAmount { get; set; }
    }

    public class PurchaseEntry : BaseDomain
    {
        public int PurchaseEntryId { get; set; }
        public string PurchaseBillNo { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string SupplierName { get; set; }
        public string CompanyName { get; set; }
        public string InvoiceNo { get; set; }
        public DateTime InvoiceDate { get; set; }
        public string PaymentMethod { get; set; }
        public string PaymentStatus { get; set; }
    }
}
