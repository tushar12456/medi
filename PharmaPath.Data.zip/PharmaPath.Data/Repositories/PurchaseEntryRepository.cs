﻿using PharmaPath.Data.Domain.Base;

namespace PharmaPath.Data.Repositories
{
    public interface IPurchaseEntryRepository
    {
        Task<int> Save(PurchaseEntry purchaseEntry);
        Task<PurchaseEntry> GetById(int id);
    }
    public class  PurchaseEntryRepository : IPurchaseEntryRepository
    {
        private readonly IGenericRepository _genericRepository;
        public PurchaseEntryRepository(IGenericRepository genericRepository) {
            _genericRepository = genericRepository;
        }

        public async Task<int> Save(PurchaseEntry purchaseEntry)
        {
            var result = await _genericRepository.SaveData<int>("PurchaseEntrySave", new
            {
                PurchaseEntryId = purchaseEntry.PurchaseEntryId,
                PurchaseDate = purchaseEntry.PurchaseDate,
                PurchaseBillNo = purchaseEntry.PurchaseBillNo,
                SupplierName = purchaseEntry.SupplierName,
                CompanyName = purchaseEntry.CompanyName,
                InvoiceNo = purchaseEntry.InvoiceNo,
                InvoiceDate = purchaseEntry.InvoiceDate,
                PaymentMethod = purchaseEntry.PaymentMethod,
                PaymentStatus = purchaseEntry.PaymentStatus,
                CurrentUserId = purchaseEntry.UpdatedBy,
                IsActive = purchaseEntry.IsActive
            });

            return result.FirstOrDefault();  
        }

        public async Task<PurchaseEntry> GetById(int id)
        {
           var result = await _genericRepository.LoadData<PurchaseEntry, dynamic>(storedProcedure: "[dbo].[PurchaseEntryGet]", new { Id = id });
            return result != null ? result.FirstOrDefault() : null;
        }


    }
}
