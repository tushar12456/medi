﻿

using PharmaPath.Data.Domain.Base;

namespace PharmaPath.Data.Repositories
{
    public interface IPurchaseMadicineRepository
    {
        Task Save(PurchaseMedicine purchaseMedicine);
        Task<IEnumerable<PurchaseMedicine>> GetByEntryId(int entryId);
    }
    public class PurchaseMadicineRepository : IPurchaseMadicineRepository
    {
        private readonly IGenericRepository _genericRepository;

        public PurchaseMadicineRepository(IGenericRepository genericRepository) {
            _genericRepository = genericRepository;
        }

        public async Task Save(PurchaseMedicine purchaseMedicine)
        {
            await _genericRepository.SaveData("PurchaseMedicineSave", new
            {
                PurchaseEntryId = purchaseMedicine.PurchaseEntryId,
                MedicineName = purchaseMedicine.MedicineName,
                Batch = purchaseMedicine.Batch,
                HSN = purchaseMedicine.HSN,
                MfgDate = purchaseMedicine.MfgDate,
                ExpiryDate = purchaseMedicine.ExpiryDate,
                Qty = purchaseMedicine.Qty,
                PurchaseRate = purchaseMedicine.PurchaseRate,
                SalesRate = purchaseMedicine.SalesRate,
                GST = purchaseMedicine.GST,
                FinalAmount = purchaseMedicine.FinalAmount,
                CurrentUserId = purchaseMedicine.UpdatedBy,
                IsActive = purchaseMedicine.IsActive
            });
        }

        public async Task<IEnumerable<PurchaseMedicine>> GetByEntryId(int entryId)
        {
            var result = await _genericRepository.LoadData<PurchaseMedicine, dynamic>(
                storedProcedure: "[dbo].[PurchaseMedicineGet]",
                new { Id = entryId });

            return result ?? Enumerable.Empty<PurchaseMedicine>();
        }


    }
}
