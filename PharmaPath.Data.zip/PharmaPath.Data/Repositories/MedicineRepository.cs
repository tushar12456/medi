﻿using PharmaPath.Data.Domain.Base;

namespace PharmaPath.Data.Repositories
{
    public interface IMedicineRepository
    {
        Task<IEnumerable<Medicine>> GetAll();
        Task<Medicine?> GetById(int id);
        Task Save(Medicine medicine);
        Task<int> Delete(int id);
    }
    public class MedicineRepository : IMedicineRepository
    {

        private readonly IGenericRepository _repository;
        public MedicineRepository(IGenericRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Medicine>> GetAll() => await _repository.LoadData<Medicine, dynamic>(storedProcedure: "MedicineGet", new { });

        public async Task<Medicine?> GetById(int id)
        {
            var results = await _repository.LoadData<Medicine, dynamic>(storedProcedure: "MedicineGet", new { Id = id });
            return results != null ? results.FirstOrDefault() : null;
        }

        public async Task Save(Medicine medicine)
        {
            await _repository.SaveData("MedicineSave"
                , new
                {
                    Id = medicine.Id,
                    MedicineName = medicine.MedicineName,
                    BrandName = medicine.BrandName,
                    BatchName = medicine.BatchName,
                    Category = medicine.Category,
                    HsnCode = medicine.HsnCode,
                    Rack = medicine.Rack,
                    MfgDate = medicine.MfgDate,
                    ExpDate = medicine.ExpDate,
                    StockQty = medicine.StockQty,
                    PurchaseRate = medicine.PurchaseRate,
                    SalesRate = medicine.SalesRate,
                    Gst = medicine.Gst,
                    CurrentUserId = medicine.UpdatedBy,
                    IsActive = medicine.IsActive
                });
        }
        public async Task<int> Delete(int id)
        {
            return await _repository.ExecuteSQL<int>($"DELETE FROM Medicine WHERE Id={id}");
        }

    }
}
