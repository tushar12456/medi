﻿using AspNetCoreRateLimit;
using GoogleApi.Extensions;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.AzureAD.UI;
using Microsoft.IdentityModel.Logging;
using NLog.Extensions.Logging;
using PharmaPath.API.Controllers;
using PharmaPath.API.Extensions;
using PharmaPath.Data;
using PharmaPath.Service.Services;


        var builder = WebApplication.CreateBuilder(args);
        var configuration = builder.Configuration;
// Program.cs (or Startup.cs)
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowReactApp", policy =>
        policy.WithOrigins("http://localhost:5173") // safer than AllowAnyOrigin
              .AllowAnyHeader()
              .AllowAnyMethod());
});

// Add services to the container.
builder.Services.AddControllers();


// Add MemoryCache service for rate limit counters
builder.Services.AddMemoryCache();
builder.Services.AddHttpClient<MedicineController>();

// Configure AspNetCoreRateLimit services
builder.Services.AddSingleton<IIpPolicyStore, MemoryCacheIpPolicyStore>();
builder.Services.AddSingleton<IRateLimitCounterStore, MemoryCacheRateLimitCounterStore>();
builder.Services.AddSingleton<IRateLimitConfiguration, RateLimitConfiguration>();
builder.Services.AddInMemoryRateLimiting();
builder.Services.Configure<IpRateLimitOptions>(builder.Configuration.GetSection("IpRateLimiting"));

builder.Services.AddAuthentication(AzureADDefaults.JwtBearerAuthenticationScheme)
            .AddAzureADBearer(configureOptions: options => configuration.Bind("AzureAd", options));

// The following flag can be used to get more descriptive errors in development environments
IdentityModelEventSource.ShowPII = false;

// Add services and repository dependency
ConfigureServices(builder.Services);

// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
//builder.Services.AddScoped<ErrorHandlingMiddleware>();
builder.Services.AddLogging(loggingBuilder =>
{
    loggingBuilder.ClearProviders();
    loggingBuilder.AddNLog();
});
var app = builder.Build();
        app.UseMiddleware<ErrorHandlingMiddleware>();



app.UseSwagger();
        app.UseSwaggerUI();
        app.UseDefaultFiles();
        app.UseStaticFiles();

        app.UseHttpsRedirection();

        app.UseAuthentication();


        //Enable Rate Limiting Middleware
        app.UseIpRateLimiting();
        
        
        app.MapControllers();

//Enable Cors Origins

app.UseCors("AllowReactApp");

app.Run();

void ConfigureServices(IServiceCollection services)
{
    services.AddSingleton<DapperContext>();

    services.RegisterRepositoryClasses(ServiceLifetime.Transient, "Repository");
    services.RegisterServiceClasses(ServiceLifetime.Transient, "Service");

    services.AddTransient<IMedicineServices, MedicineServices>();
    services.AddTransient<IPurchaseEntryServices ,PurchaseEntryServices>();
}

