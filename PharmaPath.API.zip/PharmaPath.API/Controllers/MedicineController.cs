﻿using Microsoft.AspNetCore.Mvc;
using PharmaPath.Service.DataModel;
using PharmaPath.Service.Services;

namespace PharmaPath.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicineController : ControllerBase
    {
        private readonly ILogger<MedicineController> _logger;
        private readonly IMedicineServices _medicineService;

        /// <summary>
        /// This constructor
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="medicineService"></param>
        public MedicineController(ILogger<MedicineController> logger
            , IMedicineServices medicineService)
        {
            _logger = logger;
            _medicineService = medicineService;
        }

        /// <summary>
        /// Gets the list of all Medicine.
        /// </summary>
        [HttpGet, Route("all", Name = "MedicineGetAll")]
        public async Task<ActionResult<IEnumerable<MedicineModel>>> MedicineGetAll()
        {
            var records = await _medicineService.MedicineGetAll();
            return records != null ? Ok(records) : NotFound(Enumerable.Empty<MedicineModel>());
        }

        /// <summary>
        /// Gets the Medicine details by id.
        /// </summary>
        [HttpGet, Route("{id:int}", Name = "MedicineGetById")]
        public async Task<ActionResult<MedicineModel>?> MedicineGetById(int id)
        {
            if (id == 0)
                return BadRequest("Invalid unique identifier provided!");
            var record = await _medicineService.MedicineGetById(id);
            return record != null ? Ok(record) : NotFound("Record not found!");
        }

        /// <summary>
        /// Save the Medicine details.
        /// </summary>
        /// <param name="medicineModel"></param>
        /// <returns></returns>
        [HttpPost, Route("", Name = "MedicineSave")]
        public async Task<ActionResult<bool>> MedicineSave(MedicineModel medicineModel)
        {
            if (medicineModel == null)
                return BadRequest("Invalid request data!");
            var result = await _medicineService.MedicineSave(medicineModel);
            return Ok(result);
        }

        /// <summary>
        /// Delete the Medicine details by id.
        /// </summary>
        [HttpDelete, Route("{id:int}", Name = "MedicineDelete")]
        public async Task<ActionResult<bool>> MedicineDelete(int id)
        {
            if (id == 0)
                return BadRequest("Invalid unique identifier provided!");
            return Ok(await _medicineService.MedicineDeleteById(id));
        }
    }
}
