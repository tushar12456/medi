﻿using PharmaPath.Service.DataModel;
using PharmaPath.Service.Services;
using Microsoft.AspNetCore.Mvc;

namespace PharmaPath.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly ILdapAuthenticatorService _ldapAuthenticatorService;
        private readonly ICryptoService _CryptoService;

        /// <summary>
        /// This constructor
        /// </summary>
        /// <param name="logger"></param>
        public UserController(IUserService userService
            , ILdapAuthenticatorService ldapAuthenticatorService
            , ICryptoService cryptoService)
        {
            _userService = userService;
            _ldapAuthenticatorService = ldapAuthenticatorService;
            _CryptoService = cryptoService;
        }
        [HttpPost, Route("authenticate", Name = "AuthenticateUser")]
        public async Task<ActionResult<UserDetailModel>> AuthenticateUser(FilterUserModel userLoginModel)
        {

            var dbResponse = await _userService.AuthenticateViaDatabase(userLoginModel);
            if (dbResponse != null)
                return Ok(true);

            return BadRequest("Please check Email ID and Password.");
        }
    }
}
