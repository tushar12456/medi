﻿using Microsoft.AspNetCore.Mvc;
using PharmaPath.Service.DataModel;
using PharmaPath.Service.Services;

namespace PharmaPath.API.Controllers
{
    [Route("api/[Controller]")]
    [ApiController]
    public class PurchaseEntryController: ControllerBase
    {
        private readonly IPurchaseEntryServices _purchaseEntryServices;

        public PurchaseEntryController(IPurchaseEntryServices purchaseEntryServices)
        {
            _purchaseEntryServices = purchaseEntryServices;
        }

        [HttpPost,Route("",Name ="Save")]
        public async Task<ActionResult<bool>> Save(PurchaseEntryModel purchaseEntryModel)
        {
            if (purchaseEntryModel == null)
                return BadRequest("Invalid Required Data!");
              var result =  await _purchaseEntryServices.Save(purchaseEntryModel);
            return Ok(result);
        }

        /// <summary>
        /// Gets the Medicine details by id.
        /// </summary>
        [HttpGet, Route("{id:int}", Name = "GetById")]
        public async Task<ActionResult<MedicineModel>?> GetById(int id)
        {
            if (id == 0)
                return BadRequest("Invalid unique identifier provided!");
            var record = await _purchaseEntryServices.GetById(id);
            return record != null ? Ok(record) : NotFound("Record not found!");
        }
    }
}
