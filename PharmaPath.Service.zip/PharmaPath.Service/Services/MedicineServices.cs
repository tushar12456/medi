﻿using PharmaPath.Data.Domain.Base;
using PharmaPath.Data.Repositories;
using PharmaPath.Service.DataModel;
using PharmaPath.Service.Utility;

namespace PharmaPath.Service.Services
{
    public interface IMedicineServices
    {
        Task<List<MedicineModel>> MedicineGetAll();
        Task<MedicineModel?> MedicineGetById(int id);
        Task<bool> MedicineSave(MedicineModel medicineModel);
        Task<int?> MedicineDeleteById(int id);
    }
    public class MedicineServices : IMedicineServices
    {
        private readonly IMedicineRepository _medicineRepository;

        public MedicineServices(IMedicineRepository medicineRepository)
        {
            _medicineRepository = medicineRepository;
        }
        public async Task<List<MedicineModel>> MedicineGetAll()
        {
            var modelRecords = new List<MedicineModel>();
            var dbRecords = await _medicineRepository.GetAll();
            if (dbRecords.Any())
                modelRecords = GenericMapper<Medicine, MedicineModel>.MapGenericCollection(dbRecords.ToList(), modelRecords);

            return modelRecords;
        }
        public async Task<MedicineModel?> MedicineGetById(int id)
        {
            var dbRecord = await _medicineRepository.GetById(id);
            return dbRecord != null ? GenericMapper<Medicine, MedicineModel>.Map(dbRecord, new MedicineModel()) : null;
        }
        public async Task<bool> MedicineSave(MedicineModel medicineModel)
        {
            var dbRecord = GenericMapper<MedicineModel, Medicine>.Map(medicineModel, new Medicine());
            dbRecord.UpdatedBy = medicineModel.CurrentUserId;
            await _medicineRepository.Save(dbRecord);
            return true;
        }
      
        public async Task<int?> MedicineDeleteById(int id)
        {
            return await _medicineRepository.Delete(id);
        }
    }
}
