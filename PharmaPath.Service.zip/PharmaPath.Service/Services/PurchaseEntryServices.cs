﻿using PharmaPath.Data.Domain.Base;
using PharmaPath.Data.Repositories;
using PharmaPath.Service.DataModel;
using PharmaPath.Service.Utility;

namespace PharmaPath.Service.Services
{
    public interface IPurchaseEntryServices
    {
        Task<bool> Save(PurchaseEntryModel purchaseEntryModel);
        Task<PurchaseEntryModel> GetById(int id);
    }
    public class PurchaseEntryServices : IPurchaseEntryServices
    {
        private readonly IPurchaseEntryRepository _purchaseEntryRepository;
        private readonly IPurchaseMadicineRepository _purchaseMadicineRepository;

        public PurchaseEntryServices(IPurchaseEntryRepository purchaseEntryRepository,IPurchaseMadicineRepository purchaseMadicineRepository) {
            _purchaseEntryRepository = purchaseEntryRepository;
            _purchaseMadicineRepository = purchaseMadicineRepository;
        }

        public async Task<bool>Save(PurchaseEntryModel purchaseEntryModel)
        {
            var deRecord = GenericMapper<PurchaseEntryModel, PurchaseEntry>.Map(purchaseEntryModel, new PurchaseEntry());
            deRecord.UpdatedBy = purchaseEntryModel.CurrentUserId;
            int purchaseEntryId = await _purchaseEntryRepository.Save(deRecord);

            foreach (var item in purchaseEntryModel.PurchaseMedicine)
            {
                item.PurchaseEntryId = purchaseEntryId;
                item.UpdatedBy = purchaseEntryModel.CurrentUserId;
                await _purchaseMadicineRepository.Save(item);

            }
            return true;
        }

        public async Task<PurchaseEntryModel> GetById(int id)
        {
            var dbRecord = await _purchaseEntryRepository.GetById(id);
            if (dbRecord == null) return null;

            var medicines = await _purchaseMadicineRepository.GetByEntryId(id);

            var entryModel = GenericMapper<PurchaseEntry, PurchaseEntryModel>.Map(dbRecord, new PurchaseEntryModel());
            entryModel.PurchaseMedicine = medicines
                .Select(m => GenericMapper<PurchaseMedicine, PurchaseMedicineModel>.Map(m, new PurchaseMedicineModel()))
                .ToList();

            return entryModel;
        }




    }
}
