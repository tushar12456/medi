﻿using PharmaPath. Service.DataModel;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PharmaPath. Service.Utility
{
    public static class JsonFileReader
    {
        //public static List<MenuModel> GetMenuItemsFromJson()
        //{
        //    string currentDirectory = Directory.GetCurrentDirectory();

        //    using StreamReader reader = new($"{currentDirectory}/UploadFiles/MenuItemData.json");
        //    var json = reader.ReadToEnd();
        //    var menuItems = JsonConvert.DeserializeObject<List<MenuModel>>(json);
        //    return menuItems == null || !menuItems.Any() ? new List<MenuModel>() : menuItems;
        //}
        //public static GetUserAuthorisedMenuList(List<UserRolePermissionDetailsModel> UserRoles)
        //{

        //}
    }
}
