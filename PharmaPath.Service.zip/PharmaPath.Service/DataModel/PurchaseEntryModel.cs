﻿using PharmaPath.Data.Domain.Base;

namespace PharmaPath.Service.DataModel
{
    public class PurchaseEntryModel : PurchaseEntry
    {
        public string CurrentUserId { get; set; }
        public List<PurchaseMedicineModel> PurchaseMedicine { get; set; }
    }

    public class PurchaseMedicineModel : PurchaseMedicine {
        public string CurrentUserId { get; set; }
    }
}
