﻿

using PharmaPath.Data.Domain.Base;

namespace PharmaPath.Service.DataModel
{
    public class MedicineModel :Medicine
    {
        public string? CurrentUserId { get; set; }
    }
}
