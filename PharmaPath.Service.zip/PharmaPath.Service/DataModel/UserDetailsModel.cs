﻿using PharmaPath.Data.Domain;
namespace PharmaPath. Service.DataModel
{
    public class UserDetailModel: User
    {
       
    }

    public class FilterUserModel
    {
        public string Password { get; set; } = string.Empty;
        public string EmailId { get; set; } = string.Empty;
    }

    public class UserLoginModel
    {
        public string EmailId { get; set;}
        public string? Password { get; set;}
        public string? IpAddress { get; set;}
        public byte AuthenticationType { get; set;}
    }
    public class UserCodeDateTokenModel
    {
        public string Token { get; set;} 
    }
}
