﻿CREATE PROCEDURE [dbo].[PurchaseMedicineSave]
	@PurchaseMedicineId					INT = NULL,
	@PurchaseEntryId		INT,
	@MedicineName			VARCHAR(100),
	@Batch			        VARCHAR(50),
	@HSN			        VARCHAR(50),
	@MfgDate		    DateTime,
	@ExpiryDate            DateTime,
	@Qty			    INT,
	@PurchaseRate	    DECIMAL(18,2),
	@SalesRate			DECIMAL(18,2),
	@Gst			    DECIMAL(18,2),
	@FinalAmount        DECIMAL(18,2),
	@CurrentUserId      VARCHAR(50),
	@IsActive			BIT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @ReturnId INT = @PurchaseMedicineId;

	IF @PurchaseMedicineId IS NULL OR @PurchaseMedicineId = 0
		BEGIN
			INSERT INTO [dbo].PurchaseMedicine
			   ([PurchaseEntryId]
			   ,[MedicineName]
			   ,[Batch]
			   ,[HSN]
			   ,[MfgDate]
			   ,[ExpiryDate]
			   ,[Qty]
			   ,[PurchaseRate]
			   ,[SalesRate]
			   ,[Gst]
			   ,[FinalAmount]
			   ,[CreatedBy]
			   ,[CreatedDate]
			   ,[UpdatedBy]
			   ,[UpdatedDate]
			   ,[IsActive])
			VALUES
			   (
			    @PurchaseEntryId,
				@MedicineName
				,@Batch
				,@HSN
				,@MfgDate
				,@ExpiryDate
				,@Qty
				,@PurchaseRate
				,@SalesRate
				,@Gst
				,@FinalAmount
				,@CurrentUserId
				,GETDATE()
				,@CurrentUserId
				,GETDATE()
				,@IsActive
			   )

			   SET @ReturnId = @@IDENTITY
		END
	ELSE
		BEGIN
			UPDATE [dbo].PurchaseMedicine
			SET	   [PurchaseEntryId]	= @PurchaseEntryId
			      ,[MedicineName]	= @MedicineName
				  ,[Batch]		= @Batch
				  ,[HSN]		= @HSN
				  ,[MfgDate]		= @MfgDate
				  ,[ExpiryDate]		= @ExpiryDate
				  ,[Qty]		    = @Qty
				  ,[PurchaseRate]		= @PurchaseRate
				  ,[SalesRate]		= @SalesRate
				  ,[Gst]		= @Gst
				  ,[FinalAmount]	= @FinalAmount
				  ,[UpdatedBy]		= @CurrentUserId
				  ,[UpdatedDate]		= GETDATE()
				  ,[IsActive]		= @IsActive
			WHERE PurchaseMedicineId = @PurchaseMedicineId
		END


		return @ReturnId
END
