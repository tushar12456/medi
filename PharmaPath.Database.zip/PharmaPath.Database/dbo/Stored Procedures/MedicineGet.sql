﻿CREATE PROCEDURE [dbo].[MedicineGet]
	@Id INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

    IF @Id IS NULL OR @Id = 0
		SELECT M.*
		FROM [dbo].[Medicine] M
		WHERE M.IsActive = 1;
	ELSE
		SELECT M.*
		FROM [dbo].[Medicine] M
		WHERE M.Id = @Id;
END
