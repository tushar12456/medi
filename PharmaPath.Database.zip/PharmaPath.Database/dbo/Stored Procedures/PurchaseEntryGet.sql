﻿CREATE PROCEDURE [dbo].[PurchaseEntryGet]
	@Id INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

    IF @Id IS NULL OR @Id = 0
		SELECT PE.*
		FROM [dbo].PurchaseEntry PE
		WHERE PE.IsActive = 1;
	ELSE
		SELECT PE.*
		FROM [dbo].PurchaseEntry PE
		WHERE PE.PurchaseEntryId = @Id;
END