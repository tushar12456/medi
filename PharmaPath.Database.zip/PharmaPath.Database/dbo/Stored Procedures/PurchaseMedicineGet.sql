﻿CREATE PROCEDURE [dbo].[PurchaseMedicineGet]
	@Id INT = NULL
AS
BEGIN
	SET NOCOUNT ON;

    IF @Id IS NULL OR @Id = 0
		SELECT PM.*
		FROM [dbo].PurchaseMedicine PM
		WHERE PM.IsActive = 1;
	ELSE
		SELECT PM.*
		FROM [dbo].PurchaseMedicine PM
		WHERE PM.PurchaseEntryId = @Id;
END