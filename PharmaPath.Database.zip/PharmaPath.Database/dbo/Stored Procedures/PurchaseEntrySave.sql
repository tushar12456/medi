﻿CREATE PROCEDURE [dbo].[PurchaseEntrySave]
	@PurchaseEntryId      INT = NULL,
    @PurchaseBillNo       VARCHAR(50),
    @PurchaseDate         DateTime,
    @SupplierName         VARCHAR(100),
    @CompanyName          VARCHAR(100),
    @InvoiceNo            VARCHAR(50),
    @InvoiceDate          DateTime,
    @PaymentMethod        VARCHAR(50),
    @PaymentStatus        VARCHAR(50),
    @CurrentUserId        VARCHAR(50),
    @IsActive             BIT = 1
AS
BEGIN
    SET NOCOUNT ON;
    DECLARE @ReturnId INT = @PurchaseEntryId;

    IF @PurchaseEntryId IS NULL OR @PurchaseEntryId = 0
    BEGIN
        INSERT INTO [dbo].[PurchaseEntry]
        (
            [PurchaseBillNo],
            [PurchaseDate],
            [SupplierName],
            [CompanyName],
            [InvoiceNo],
            [InvoiceDate],
            [PaymentMethod],
            [PaymentStatus],
            [CreatedBy],
            [CreatedDate],
            [UpdatedBy],
            [UpdatedDate],
            [IsActive]
        )
        VALUES
        (
            @PurchaseBillNo,
            @PurchaseDate,
            @SupplierName,
            @CompanyName,
            @InvoiceNo,
            @InvoiceDate,
            @PaymentMethod,
            @PaymentStatus,
            @CurrentUserId,
            GETDATE(),
            @CurrentUserId,
            GETDATE(),
            @IsActive
        )

        SET @ReturnId = @@IDENTITY
    END
    ELSE
    BEGIN
        UPDATE [dbo].[PurchaseEntry]
        SET 
            [PurchaseBillNo] = @PurchaseBillNo,
            [PurchaseDate] = @PurchaseDate,
            [SupplierName] = @SupplierName,
            [CompanyName] = @CompanyName,
            [InvoiceNo] = @InvoiceNo,
            [InvoiceDate] = @InvoiceDate,
            [PaymentMethod] = @PaymentMethod,
            [PaymentStatus] = @PaymentStatus,
            [UpdatedBy] = @CurrentUserId,
            [UpdatedDate] = GETDATE(),
            [IsActive] = @IsActive
        WHERE PurchaseEntryId = @PurchaseEntryId

        SET @ReturnId = @PurchaseEntryId
    END

    -- CRITICAL FIX: SELECT instead of RETURN to get ID in C# result set
    SELECT @ReturnId AS PurchaseEntryId;
END
