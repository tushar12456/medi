﻿CREATE PROCEDURE [dbo].[MedicineSave]
	@Id					INT = NULL,
	@MedicineName		VARCHAR(250),
	@BrandName			VARCHAR(200),
	@BatchName			VARCHAR(150),
	@Category			VARCHAR(50),
	@HsnCode			VARCHAR(50),
	@Rack			    VARCHAR(25),
	@MfgDate		    DateTime,
	@ExpDate            DateTime,
	@StockQty			VARCHAR(100),
	@PurchaseRate	    VARCHAR(50),
	@SalesRate			VARCHAR(50),
	@Gst			    VARCHAR(50),
	@CurrentUserId      VARCHAR(50),
	@IsActive			BIT = 1
AS
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;
	DECLARE @ReturnId INT = @Id;

	IF @Id IS NULL OR @Id = 0
		BEGIN
			INSERT INTO [dbo].[Medicine]
			   ([MedicineName]
			   ,[BrandName]
			   ,[BatchName]
			   ,[Category]
			   ,[HsnCode]
			   ,[Rack]
			   ,[MfgDate]
			   ,[ExpDate]
			   ,[StockQty]
			   ,[PurchaseRate]
			   ,[SalesRate]
			   ,[Gst]
			   ,[CreatedBy]
			   ,[CreatedOn]
			   ,[UpdatedBy]
			   ,[UpdatedOn]
			   ,[IsActive])
			VALUES
			   (
				@MedicineName
				,@BrandName
				,@BatchName
				,@Category
				,@HsnCode
				,@Rack
				,@MfgDate
				,@ExpDate
				,@StockQty
				,@PurchaseRate
				,@SalesRate
				,@Gst
				,@CurrentUserId
				,GETDATE()
				,@CurrentUserId
				,GETDATE()
				,@IsActive
			   )

			   SET @ReturnId = @@IDENTITY
		END
	ELSE
		BEGIN
			UPDATE [dbo].[Medicine]
			SET	   [MedicineName]	= @MedicineName
				  ,[BrandName]		= @BrandName
				  ,[BatchName]		= @BatchName
				  ,[Category]		= @Category
				  ,[HsnCode]		= @HsnCode
				  ,[Rack]		    = @Rack
				  ,[MfgDate]		= @MfgDate
				  ,[ExpDate]		= @ExpDate
				  ,[StockQty]		= @StockQty
				  ,[PurchaseRate]	= @PurchaseRate
				  ,[SalesRate]		= @SalesRate
				  ,[Gst]		    = @Gst
				  ,[UpdatedBy]		= @CurrentUserId
				  ,[UpdatedOn]		= GETDATE()
				  ,[IsActive]		= @IsActive
			WHERE Id = @Id
		END


		return @ReturnId
END
