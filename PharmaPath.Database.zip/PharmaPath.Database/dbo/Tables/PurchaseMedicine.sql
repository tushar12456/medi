﻿CREATE TABLE [dbo].[PurchaseMedicine]
(
	[PurchaseMedicineId] [int] IDENTITY(1,1) NOT NULL,
	[PurchaseEntryId] [int] NULL,
	[MedicineName] [varchar](100) NULL,
	[Batch] [varchar](50) NULL,
	[HSN] [varchar](50) NULL,
	[MfgDate] [date] NULL,
	[ExpiryDate] [date] NULL,
	[Qty] [int] NULL,
	[PurchaseRate] [decimal](10, 2) NULL,
	[SalesRate] [decimal](10, 2) NULL,
	[GST] [decimal](5, 2) NULL,
	[FinalAmount] [decimal](12, 2) NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL DEFAULT GetDate(),
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NULL DEFAULT (1), 
    CONSTRAINT [PK_PurchaseMedicine] PRIMARY KEY ([PurchaseMedicineId])
)
