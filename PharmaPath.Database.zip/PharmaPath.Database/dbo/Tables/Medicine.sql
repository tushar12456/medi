﻿CREATE TABLE [dbo].[Medicine]
(
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[MedicineName] [varchar](250) NOT NULL,
	[BrandName] [varchar](200) NOT NULL,
	[BatchName] [varchar](150) NOT NULL,
	[Category] [varchar](50) NOT NULL,
	[HsnCode] [varchar](50) NOT NULL,
	[Rack] [varchar](25) NULL,
	[MfgDate] [datetime] NOT NULL,
	[ExpDate] [datetime] NOT NULL,
	[StockQty] [varchar](100) NOT NULL,
	[PurchaseRate] [varchar](50) NOT NULL,
	[SalesRate] [varchar](50) NOT NULL,
	[Gst] [varchar](50) NOT NULL,
	[CreatedBy] [varchar](10) NULL,
	[CreatedOn] [datetime] NULL DEFAULT GetDate(),
	[UpdatedBy] [varchar](10) NULL,
	[UpdatedOn] [datetime] NULL,
	[IsActive] [bit] NOT NULL DEFAULT (1), 
    CONSTRAINT [PK_Medicine] PRIMARY KEY ([Id])
	)

