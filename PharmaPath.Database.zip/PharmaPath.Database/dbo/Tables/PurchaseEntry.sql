﻿CREATE TABLE [dbo].[PurchaseEntry]
(
	[PurchaseEntryId] [int] IDENTITY(1,1) NOT NULL,
	[PurchaseBillNo] [varchar](50) NULL,
	[PurchaseDate] [date] NULL,
	[SupplierName] [varchar](100) NULL,
	[CompanyName] [varchar](100) NULL,
	[InvoiceNo] [varchar](50) NULL,
	[InvoiceDate] [date] NULL,
	[PaymentMethod] [varchar](50) NULL,
	[PaymentStatus] [varchar](50) NULL,
	[CreatedBy] [int] NULL,
	[CreatedDate] [datetime] NULL DEFAULT GetDate(),
	[UpdatedBy] [int] NULL,
	[UpdatedDate] [datetime] NULL,
	[IsActive] [bit] NULL DEFAULT (1), 
    CONSTRAINT [PK_PurchaseEntry] PRIMARY KEY ([PurchaseEntryId])
)
