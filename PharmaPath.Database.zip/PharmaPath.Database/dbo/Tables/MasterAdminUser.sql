﻿CREATE TABLE [dbo].[MasterAdminUser]
(
	Id INT NOT NULL PRIMARY KEY IDENTITY,
	EmailId varchar(100) NOT NULL,
	Password varchar(100) NOT NULL,
	FullName varchar(150) NOT NULL,
	IsActive bit NOT NULL,
)
